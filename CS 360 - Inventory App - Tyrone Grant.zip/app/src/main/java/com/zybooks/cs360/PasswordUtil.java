package com.zybooks.cs360;

import android.util.Base64;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Salted password hashing using PBKDF2.
 * Stored format: base64(salt) + ":" + base64(hash)
 * Requires API 26+ for PBKDF2WithHmacSHA256.
 */
public final class PasswordUtil { // password util class

    // ---------- Constants ----------
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 120_000;
    private static final int KEY_BITS = 256;
    private static final int SALT_BYTES = 16;

    private PasswordUtil() {}

    public static String hash(String password) { // hash password
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = pbkdf2(password, salt);
        return encode(salt) + ":" + encode(hash);
    }

    public static boolean verify(String password, String stored) { // verify password
        String[] parts = stored.split(":");
        if (parts.length != 2) return false;

        byte[] salt = Base64.decode(parts[0], Base64.NO_WRAP);
        byte[] expected = Base64.decode(parts[1], Base64.NO_WRAP);
        byte[] actual = pbkdf2(password, salt);

        // Constant-time comparison
        return MessageDigest.isEqual(expected, actual);
    }

    private static byte[] pbkdf2(String password, byte[] salt) { // pbkdf2 to hash password
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance(ALGORITHM).generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Password hashing failed", e);
        } finally {
            spec.clearPassword();
        }
    }

    private static String encode(byte[] bytes) { // encode password
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }
}