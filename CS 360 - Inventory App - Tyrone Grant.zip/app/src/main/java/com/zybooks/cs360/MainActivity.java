package com.zybooks.cs360;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// ---------- MainActivity ----------
public class MainActivity extends AppCompatActivity {

    // ---------- Constants ----------
    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS = "inventory_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_SMS_PHONE = "sms_phone";

    private AppDatabase db;
    private InventoryAdapter adapter;

    // ---------- UI ----------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Enable edge-to-edge layout
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // database instance
        db = AppDatabase.getInstance(this);
        // recycler to show items
        RecyclerView recycler = findViewById(R.id.recyclerInventory);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        // adapter to show items
        adapter = new InventoryAdapter(new InventoryAdapter.Listener() {
            @Override
            public void onQuantityChanged(InventoryItem item, int newQty) {
                int oldQty = item.quantity;   // read on the UI thread, before the change
                AppDatabase.dbExecutor.execute(() -> {
                    item.quantity = newQty;
                    db.inventoryDao().update(item);
                    if (newQty == 0 && oldQty > 0) sendOutOfStockSms(item);
                    refreshList();
                });
            }

            @Override
            public void onEdit(InventoryItem item) { // edit dialog
                showEditDialog(item);
            }

            @Override
            public void onDelete(InventoryItem item) { // delete dialog
                AppDatabase.dbExecutor.execute(() -> {
                    db.inventoryDao().delete(item);
                    refreshList();
                });
            }
        });
        recycler.setAdapter(adapter);

        setupAddButton();
        setupTopBar();

        AppDatabase.dbExecutor.execute(this::refreshList);
    }

    private void refreshList() { // refresh list
        List<InventoryItem> fresh = db.inventoryDao().getAll(); // read on a background thread
        List<InventoryItem> zeroed = db.inventoryDao().getZeroed();
        runOnUiThread(() -> {
            adapter.setItems(fresh);
            updateBadge(zeroed.size());
        });
    }

    private void setupAddButton() { // add button
        EditText nameField = findViewById(R.id.editItemName);
        EditText qtyField = findViewById(R.id.editItemQty);

        findViewById(R.id.buttonAddItem).setOnClickListener(v -> {
            String name = nameField.getText().toString().trim();
            String qtyStr = qtyField.getText().toString().trim();
            if (name.isEmpty() || qtyStr.isEmpty()) return;

            int qty = Integer.parseInt(qtyStr);
            AppDatabase.dbExecutor.execute(() -> {
                InventoryItem newItem = new InventoryItem(name, qty);
                db.inventoryDao().insert(newItem);
                if (qty == 0) sendOutOfStockSms(newItem);
                refreshList();
            });
            nameField.setText("");
            qtyField.setText("");
        });
    }

    // ---------- Edit ----------

    private void showEditDialog(InventoryItem item) {
        EditText nameField = new EditText(this);
        nameField.setHint("Item name");
        nameField.setInputType(InputType.TYPE_CLASS_TEXT);
        nameField.setText(item.itemName);

        EditText qtyField = new EditText(this);
        qtyField.setHint("Quantity");
        qtyField.setInputType(InputType.TYPE_CLASS_NUMBER);
        qtyField.setText(String.valueOf(item.quantity));

        LinearLayout layout = dialogLayout();
        layout.addView(nameField);
        layout.addView(qtyField);

        new AlertDialog.Builder(this)
                .setTitle("Edit item")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String name = nameField.getText().toString().trim();
                    String qtyStr = qtyField.getText().toString().trim();
                    if (name.isEmpty() || qtyStr.isEmpty()) {
                        toast("Name and quantity are required");
                        return;
                    }
                    int newQty;
                    try {
                        newQty = Integer.parseInt(qtyStr);
                    } catch (NumberFormatException e) {
                        toast("Enter a valid quantity");
                        return;
                    }
                    int oldQty = item.quantity;
                    AppDatabase.dbExecutor.execute(() -> {
                        item.itemName = name;
                        item.quantity = newQty;
                        db.inventoryDao().update(item);
                        if (newQty == 0 && oldQty > 0) sendOutOfStockSms(item);
                        refreshList();
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private LinearLayout dialogLayout() { // layout for dialog
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad / 2, pad, 0);
        return layout;
    }

    // ---------- Top bar ----------

    private void setupTopBar() {
        findViewById(R.id.buttonNotifications)
                .setOnClickListener(v -> showSmsSettingsDialog());

        findViewById(R.id.buttonMenu).setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, v);
            popup.inflate(R.menu.inventory_menu);
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.action_logout) {
                    logout();
                    return true;
                }
                return false;
            });
            popup.show();
        });
    }

    private void logout() { // logout to login screen
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    // ---------- SMS alerts: settings, permission, sending ----------

    private void showSmsSettingsDialog() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        SwitchCompat toggle = new SwitchCompat(this);
        toggle.setText("Text me when an item hits 0");
        toggle.setChecked(prefs.getBoolean(KEY_SMS_ENABLED, false));

        EditText phoneField = new EditText(this);
        phoneField.setHint("Phone number");
        phoneField.setInputType(InputType.TYPE_CLASS_PHONE);
        phoneField.setText(prefs.getString(KEY_SMS_PHONE, ""));

        LinearLayout layout = dialogLayout();
        layout.addView(toggle);
        layout.addView(phoneField);

        new AlertDialog.Builder(this)
                .setTitle("SMS alerts")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    boolean enabled = toggle.isChecked();
                    String number = phoneField.getText().toString().trim();

                    if (enabled && number.isEmpty()) {
                        toast("Enter a phone number to turn alerts on");
                        return;
                    }
                    prefs.edit()
                            .putBoolean(KEY_SMS_ENABLED, enabled)
                            .putString(KEY_SMS_PHONE, number)
                            .apply();

                    if (enabled) {
                        ensureSmsPermission();
                    } else {
                        toast("SMS alerts are off");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private boolean hasSmsPermission() { // check permission
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureSmsPermission() { // request permission
        if (hasSmsPermission()) {
            toast("SMS alerts are on");
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // ---------- SMS alerts: sending ----------
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                toast("SMS alerts are on");
            } else {
                // Denied: the app keeps working, but no texts are sent
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean(KEY_SMS_ENABLED, false).apply();
                toast("Permission denied. SMS alerts are off, but the app still works.");
            }
        }
    }

    // ---------- SMS alerts: sending ----------
    private void sendOutOfStockSms(InventoryItem item) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_SMS_ENABLED, false)) return;

        String phone = prefs.getString(KEY_SMS_PHONE, "");
        if (phone.isEmpty()) return;

        if (!hasSmsPermission()) {
            toast("SMS alert not sent: permission not granted");
            return;
        }

        try {
            SmsManager sms = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    ? getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            sms.sendTextMessage(phone, null,
                    "Inventory alert: " + item.itemName + " is out of stock (0 left).",
                    null, null);
            toast("SMS alert sent for " + item.itemName);
        } catch (Exception e) {
            toast("SMS alert failed to send");
        }
    }

    private void toast(String message) { // toast to show message
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    private void updateBadge(int count) { // update badge to show count
        TextView badge = findViewById(R.id.textAlertBadge);
        badge.setText(String.valueOf(count));
        badge.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
    }
}