package com.zybooks.cs360;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity { // login activity

    // class variables
    private AppDatabase db;
    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private boolean passwordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) { // on create for login screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = AppDatabase.getInstance(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> attemptLogin()); // login button

        // "Sign Up" link at the bottom opens the signup screen
        findViewById(R.id.tvSignUp).setOnClickListener(v ->
                startActivity(new Intent(this, SignupActivity.class)));

        // Login is the launcher screen, so back just closes the app
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Show/hide password toggle (hidden by default)
        ImageView ivToggle = findViewById(R.id.ivTogglePassword);
        ivToggle.setOnClickListener(v -> {
            passwordVisible = !passwordVisible;
            etPassword.setTransformationMethod(passwordVisible
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            etPassword.setSelection(etPassword.getText().length());
        });
    }

    private void attemptLogin() { // login attempt
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter your username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        btnLogin.setEnabled(false);   // prevent double taps while hashing

        AppDatabase.dbExecutor.execute(() -> { // hash the password in the background
            // The username is stored in the users table's username column
            User user = db.userDao().findByUsername(username);
            boolean valid = user != null
                    && PasswordUtil.verify(password, user.passwordHash);

            runOnUiThread(() -> {
                btnLogin.setEnabled(true);
                if (valid) {
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else {
                    // Same message for unknown user and wrong password
                    etPassword.setText("");
                    Toast.makeText(this, "Invalid username or password",
                            Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
}
