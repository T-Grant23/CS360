package com.zybooks.cs360;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.Database;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// ---------- AppDatabase ----------
@Database(entities = {InventoryItem.class, User.class}, version = 1)

public abstract class AppDatabase extends RoomDatabase { // database class

    // DAO objects for each table
    public abstract InventoryDao inventoryDao();
    public abstract UserDao userDao();

    // Singleton instance
    private static volatile AppDatabase INSTANCE;
    public static final ExecutorService dbExecutor =
            Executors.newFixedThreadPool(2);

    public static AppDatabase getInstance(Context context) { // get instance of database
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class, "warehouse.db").build();
                }
            }
        }
        return INSTANCE;
    }
}

