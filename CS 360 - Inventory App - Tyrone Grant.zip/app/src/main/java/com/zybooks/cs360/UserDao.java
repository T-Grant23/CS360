package com.zybooks.cs360;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface UserDao { // user DAO - database access object
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(User user);   // throws if username already exists

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User findByUsername(String username);
}
