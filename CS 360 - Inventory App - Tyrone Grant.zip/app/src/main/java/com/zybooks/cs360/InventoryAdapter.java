package com.zybooks.cs360;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter
        extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> { // adapter for recycler view

    public interface Listener { // listener for adapter
        void onQuantityChanged(InventoryItem item, int newQty);
        void onDelete(InventoryItem item);
        void onEdit(InventoryItem item);

    }

    private List<InventoryItem> items = new ArrayList<>(); // list of items
    private final Listener listener;

    public InventoryAdapter(Listener listener) { this.listener = listener; } // constructor

    public void setItems(List<InventoryItem> newItems) {
        items = newItems;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder { // view holder for each item
        TextView name, qty;
        ImageButton decrease, increase, menu;
        ViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.textItemName);
            qty = v.findViewById(R.id.textItemQty);
            decrease = v.findViewById(R.id.buttonDecrease);
            increase = v.findViewById(R.id.buttonIncrease);
            menu = v.findViewById(R.id.buttonRowMenu);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // create each item
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_row, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) { // bind each item
        InventoryItem item = items.get(position);
        h.name.setText(item.itemName);
        h.qty.setText(String.valueOf(item.quantity));

        // Decrease can't go below zero
        h.decrease.setEnabled(item.quantity > 0);

        h.increase.setOnClickListener(v -> // increase button
                listener.onQuantityChanged(item, item.quantity + 1));
        h.decrease.setOnClickListener(v -> // decrease button
                listener.onQuantityChanged(item, item.quantity - 1));

        h.menu.setOnClickListener(v -> { // menu button
            PopupMenu popup = new PopupMenu(v.getContext(), v);
            popup.inflate(R.menu.overflow_menu);
            popup.setOnMenuItemClickListener(mi -> {
                if (mi.getItemId() == R.id.action_delete) {
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("Delete " + item.itemName + "?")
                            .setPositiveButton("Delete",
                                    (d, w) -> listener.onDelete(item))
                            .setNegativeButton("Cancel", null)
                            .show();
                    return true;
                }
                // action_edit is the default case
                listener.onEdit(item);
                return true;
            });
            popup.show(); // show menu
        });
    }

    @Override
    public int getItemCount() { return items.size(); } // get item count
}
