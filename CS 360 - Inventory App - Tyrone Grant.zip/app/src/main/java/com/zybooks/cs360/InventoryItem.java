package com.zybooks.cs360;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "inventory")
public class InventoryItem { // inventory item class
    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    @ColumnInfo(name = "item_name")
    public String itemName;

    public int quantity;

    public InventoryItem(@NonNull String itemName, int quantity) { // constructor
        this.itemName = itemName;
        this.quantity = quantity;
    }
}
