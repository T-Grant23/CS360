package com.zybooks.cs360;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface InventoryDao { // inventory DAO - database access object

    // CRUD operations for the inventory table
    @Insert
    long insert(InventoryItem item);

    @Update
    void update(InventoryItem item);

    @Delete
    void delete(InventoryItem item);

    @Query("SELECT * FROM inventory ORDER BY item_name")
    List<InventoryItem> getAll();   // for the recycler view

    @Query("SELECT * FROM inventory WHERE quantity = 0")
    List<InventoryItem> getZeroed();   // for low-inventory SMS alerts
}
