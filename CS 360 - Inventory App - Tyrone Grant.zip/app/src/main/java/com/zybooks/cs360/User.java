package com.zybooks.cs360;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

// ---------- User ----------
@Entity(tableName = "users",
        indices = {@Index(value = "username", unique = true)})
public class User { // user class
    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public String username;

    @NonNull
    @ColumnInfo(name = "password_hash")
    public String passwordHash;

    public User(@NonNull String username, @NonNull String passwordHash) { // constructor
        this.username = username;
        this.passwordHash = passwordHash;
    }
}

