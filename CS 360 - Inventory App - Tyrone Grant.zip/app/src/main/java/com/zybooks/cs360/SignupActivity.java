package com.zybooks.cs360;

import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity { // signup activity

    // ---------- Constants ----------
    private static final int MIN_PASSWORD_LENGTH = 6;

    private AppDatabase db;
    private EditText etUsername;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) { // on create for signup screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        db = AppDatabase.getInstance(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnSignUp = findViewById(R.id.btnSignUp);

        btnSignUp.setOnClickListener(v -> attemptSignup());

        // Back arrow and "Sign In" link both return to the login screen
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.tvSignIn).setOnClickListener(v -> finish());

        setupVisibilityToggle(R.id.ivTogglePassword, etPassword);
        setupVisibilityToggle(R.id.ivToggleConfirm, etConfirmPassword);
    }

    private void setupVisibilityToggle(int toggleId, EditText field) { // toggle password visibility
        ImageView toggle = findViewById(toggleId);
        toggle.setOnClickListener(v -> {
            boolean currentlyHidden =
                    field.getTransformationMethod() instanceof PasswordTransformationMethod;
            field.setTransformationMethod(currentlyHidden
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            field.setSelection(field.getText().length());
        });
    }

    private void attemptSignup() { // signup attempt
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirm = etConfirmPassword.getText().toString();

        // Validate input before touching the database
        if (username.isEmpty()) {
            etUsername.setError("Enter a username");
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            etPassword.setError("Use at least " + MIN_PASSWORD_LENGTH + " characters");
            return;
        }
        if (!password.equals(confirm)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }

        btnSignUp.setEnabled(false);

        AppDatabase.dbExecutor.execute(() -> { // hash the password in the background
            if (db.userDao().findByUsername(username) != null) {
                showUsernameTaken();
                return;
            }

            String hash = PasswordUtil.hash(password);
            try {
                db.userDao().insert(new User(username, hash));
                runOnUiThread(() -> {
                    Toast.makeText(this, "Account created. Please sign in.",
                            Toast.LENGTH_LONG).show();
                    finish();   // back to the login screen
                });
            } catch (SQLiteConstraintException e) {
                // Backstop in case two sign-ups race each other
                showUsernameTaken();
            }
        });
    }

    private void showUsernameTaken() {
        runOnUiThread(() -> {
            btnSignUp.setEnabled(true);
            etUsername.setError("That username is already taken");
        });
    }
}